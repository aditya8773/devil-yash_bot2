### Powered By @darkdevil898 & @ALEXBADHACKER 

### Join @ALEXBADHACKER For More Update

### Join @ALEXBADHACKER

### Join Our Chats @darkdevil9793


### Powered By [Dark Devil](https://t.me/darkdevil9793)


### ABOUT THIS BOT
🥀 Best Smart Voice Chat Music Bot 📢 For All Telegram Groups or Channels This Bot Support Video play Or Audio Play Both ||

## Deploy
🌷 You can Deploy Easily Fork repo and Give Start 🌷

## 🥀 Bot Deploy On Workflow / (KAALI LINUX)
 At 1st Import This Repo Then Input All Value In Internal File || Then Proceed Kaali Linux Value Or Ect.

## 🥀 Kaali Linux Tutorial

[Kaali Linux](https://youtu.be/_nZT5lhcL8U)

## ⚒️ 𝐂𝐫𝐞𝐝𝐢𝐭
[DARKDEVIL](https://t.me/@darkdevil898)

## Telegram 🏪

[![Telegram Group](https://img.shields.io/badge/Telegram-Group-brightgreen)](https://t.me/darkdevil979)

[![Telegram Channel](https://img.shields.io/badge/Telegram-Channel-brightgreen)](https://t.me/darkdevil9793)

## YouTube 📺

[YouTube Channel](https://youtube.com/channel/UCUkj6FFzdsOO5acUXVOEECg)

### Deploy To Heroku

[![Deploy+On+Heroku](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/BikashHalderNew/BgtMusic)

s://github.com/BikashHalderNew/BgtMusic)


 VPS DEPLOY                                                                                          
💥 𝐎𝐧𝐥𝐲 𝐅𝐨𝐫 𝐅𝐢𝐫𝐬𝐭 𝐓𝐢𝐦𝐞 (𝐕𝐏𝐒) 💞

1) sudo apt update && sudo apt install git curl python3-pip ffmpeg -y

2) curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash

3) source ~/.bashrc

4) nvm install node

5. Clone the Repository :
git clone https://github.com/BikashhalderNew/BgtMusic &&  cd BgtMusic

6. Install Installer : 
pip3 install -r Installer

8. Editing Vars:
vi Internal 
Edit Internal with your values or you can simple copy a config from here and paste it to your notepad, then edit and paste there.
Press I button on keyboard to start editing.
Press Ctrl + C  once you are done with editing vars and type :wq to save Internal or :qa to exit editing.

9. Finally Run BGT Music Bot :
python3 -m modules 


#### 🥺 Copy Pasters You Can Copy This Repo But Must Give Credits ...

### 🌷 Owner Of This Repository 🇮🇳
[![Dark Devil](https://te.legra.ph/file/840fed0100164af249bb8.jpg)](https://t.me/darkdevil898)


#### Main Developer = [DARK DEVIL](https://t.me/darkdevil898)

## 💕 Special Thanks

✅ Aditya Halder Thanks For Fixed All Error Or Lovely Support 💕

### 🥳 𝐒𝐩𝐞𝐜𝐢𝐚𝐥 𝐓𝐡𝐚𝐧𝐤𝐬 𝐅𝐨𝐫 𝐓𝐡𝐞𝐢𝐫 𝐒𝐨𝐮𝐫𝐜𝐞𝐬 🥳

- [TeamYukki](https://github.com/teamyukki)
- [Pyrogram](https://github.com/pyrogram/pyrogram)
- [Py-Tgcalls](https://github.com/pytgcalls/pytgcalls)

## 🥀 Powered By [Darkdevil](https://t.me/darkdevil898) & [ALEX HACKER](https://t.me/ALEXBADHACKER)
)

